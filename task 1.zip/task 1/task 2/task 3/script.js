let currentPlayer = "X";
let board = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;

const statusText = document.getElementById("status");
const cells = document.querySelectorAll(".cell");

const winningConditions = [
    [0,1,2],
    [3,4,5],
    [6,7,8],
    [0,3,6],
    [1,4,7],
    [2,5,8],
    [0,4,8],
    [2,4,6]
];

function makeMove(index){

    if(board[index] !== "" || !gameActive){
        return;
    }

    board[index] = currentPlayer;
    cells[index].textContent = currentPlayer;

    checkWinner();

    if(gameActive){
        currentPlayer = currentPlayer === "X" ? "O" : "X";
        statusText.textContent = `Player ${currentPlayer}'s Turn`;
    }
}

function checkWinner(){

    for(let condition of winningConditions){

        let a = board[condition[0]];
        let b = board[condition[1]];
        let c = board[condition[2]];

        if(a === "" || b === "" || c === ""){
            continue;
        }

        if(a === b && b === c){
            statusText.textContent = `Player ${a} Wins!`;
            gameActive = false;
            return;
        }
    }

    if(!board.includes("")){
        statusText.textContent = "Match Draw!";
        gameActive = false;
    }
}

function resetGame(){

    board = ["", "", "", "", "", "", "", "", ""];
    gameActive = true;
    currentPlayer = "X";

    statusText.textContent = "Player X's Turn";

    cells.forEach(cell => {
        cell.textContent = "";
    });
}